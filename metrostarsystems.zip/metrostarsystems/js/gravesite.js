// JavaScript Document
//gravesites variable holds the new instance of http request
var graves = new XMLHTTPRequest();

graves.open("GET", "");

var xhr = new XMLHttpRequest();
xhr.open("GET", "http://www.codecademy.com/", false);
xhr.send();